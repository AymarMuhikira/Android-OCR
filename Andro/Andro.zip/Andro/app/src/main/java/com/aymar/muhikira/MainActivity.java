package com.aymar.muhikira;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.vision.text.TextRecognizer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView image;
    Button img_btn;
    Button classify_btn;
    TextView display_result;
    TextRecognizer textRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img_btn = (Button)findViewById(R.id.btn_Img);
        classify_btn = (Button)findViewById(R.id.btn_recognise);
        image = (ImageView)findViewById(R.id.Img_Capture);
        display_result = (TextView)findViewById(R.id.textBox);

        img_btn.setOnClickListener(this);
        classify_btn.setOnClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        Bitmap bitmap = (Bitmap)data.getExtras().get("data");
        image.setImageBitmap(bitmap);
    }

    @Override
    public void onClick(View v){
        if(v.getId()==R.id.btn_Img){
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,0);
        }
    }
}
